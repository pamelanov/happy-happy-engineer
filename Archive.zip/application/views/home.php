
 <!-- <div class="row">

    <a href="#" class="thumbnail">
      <img src="<?php echo base_url();?>pictures/wallpaper_jeans.png" alt="foto_slideshow">
    </a>

</div>-->
 <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
  <!-- Indicators -->
  <ol class="carousel-indicators">
    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
   <li data-target="#carousel-example-generic" data-slide-to="3"></li>
  </ol>

  <!-- Wrapper for slides -->
  <div class="carousel-inner" role="listbox">
    <div class="item active">
      <center><img id="image-slide" src="<?php echo base_url();?>pictures/slides/slide_01.png" alt="..."></center>
      <div class="carousel-caption">
        <h3>Happy Happy Engineer</h3>
		hmm coba
      </div>
    </div>
    <div class="item">
      <img id="image-slide" src="<?php echo base_url();?>pictures/slides/slide_02.png" alt="...">
      <div class="carousel-caption">
        <h3>Get Your Discounts</h3>
		Up to 70%
      </div>
	</div>
	      <div class="item">
      <img id="image-slide" src="<?php echo base_url();?>pictures/slides/slide_03.png" alt="...">
      <div class="carousel-caption">
        <h3>Support Your Local Brands</h3>
		We are proud of Indonesia
      </div>
		  </div>
	      <div class="item">
      <img id="image-slide" src="<?php echo base_url();?>pictures/slides/slide_04.png" alt="...">
      <div class="carousel-caption">
          <h3>Follow Our Instagram</h3>
		Give us a shoutout
      </div>
    </div>
    
  </div>

  <!-- Controls -->
  <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
    <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
    <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<div class="row">
  <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="<?php echo base_url();?>pictures/H2E_1488.jpg" alt="girl section">
      <div class="caption">
        <h3>Browse Girls Section</h3>
        <p>Explore our girl collection and get discounts for early buyers!</p>
        <p><a href="#" class="btn btn-danger" role="button">Browse</a>

      </div>
    </div>
  </div>
    <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="<?php echo base_url();?>pictures/H2E_6849.jpg" alt="boy section">
      <div class="caption">
        <h3>Browse Boys Section</h3>
        <p>Explore our boys collection and get discounts for early buyers!</p>
        <p><a href="#" class="btn btn-danger" role="button">Browse</a>

      </div>
    </div>
  </div>
	    <div class="col-sm-6 col-md-4">
    <div class="thumbnail">
      <img src="<?php echo base_url();?>pictures/H2E_4374.jpg" alt="boy section">
      <div class="caption">
        <h3>Browse Boys Section</h3>
        <p>Explore our boys collection and get discounts for early buyers!</p>
        <p><a href="#" class="btn btn-danger" role="button">Browse</a>
      </div>
    </div>
  </div>
</div>
		
		<!--<div class="media">
  <div class="media-left">
    <a href="#">
      <img class="media-object" src="<?php echo base_url();?>pictures/brand_logo_resized.jpg" alt="picture">
    </a>
  </div>
  <div class="media-body">
    <h4 class="media-heading">Media heading</h4>
	Cras sit amet nibh libero, in gravida nulla. Nulla vel metus scelerisque ante sollicitudin commodo. Cras purus odio, vestibulum in vulputate at, tempus viverra turpis. Fusce condimentum nunc ac nisi vulputate fringilla. Donec lacinia congue felis in faucibus.
  </div>
</div>-->
  