module Bootstrap
  VERSION       = '3.3.4'
  BOOTSTRAP_SHA = 'f5250d0a0e2a7cfed77f55654027ff151ebe5aeb'
end
