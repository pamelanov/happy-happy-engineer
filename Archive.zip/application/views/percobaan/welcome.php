<html>
	<head>
		<link rel="stylesheet" href="welcome.css">
		<title>Happy-Happy Engineering</title>
	<head>
	<body>

		<div id="hihi">
			
			<div id="tulisan">
				<h2><span>Happy-Happy Engineer</span></h2>
			</div>
		</div>
		<div id="menu">
			<ul>
			  <li><a href="default.asp">Home</a></li>
			  <li><a href="news.asp">News</a></li>
			  <li><a href="contact.asp">Contact</a></li>
			  <li><a href="about.asp">About</a></li>
			</ul>
		</div>
		
	</body>
</html>