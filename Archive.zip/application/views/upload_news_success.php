
<div class="w3-card-24 w3-amber" id="form-upload">

<p class="text-center" id="upload_success">Your file was successfully uploaded.</br>
<button type="button" class="btn btn-danger"><a href="<?php echo base_url(); ?>index.php/upload_news">Upload Another News!<a/></button>
</p>
</div>
