
<div class="w3-card-24 w3-amber" id="form-upload">

<p class="text-center" id="upload_success">Your file was successfully edited.</br>
<button type="button" class="btn btn-danger"><a href="<?php echo base_url(); ?>index.php/all_collections">See All Collections<a/></button>
</p>
</div>
