<div id="about_us">
  <!-- <div class="row" id="pengganti_slideshow">

    <a href="#" class="thumbnail">
      <img src="<?php  base_url();?>pictures/wallpaper_jeans.png" alt="foto_slideshow">
    </a>
 -->
  <div class= "row" id="about_us_pict">
    <div class="col-sm-6 col-md-4 col-xs-6">
      <img src ="<?php echo base_url();?>pictures/brand_logo_resized.jpg" alt="picture">
     </div> 
    <div class="col-sm-8 col-md-8 col-xs-12">
      <div id="tulisan">
        <h2> blablablablablablablbalbla </h2>   
      </div>
    </div>
  </div>

  <div class="row">

  </div> 
  

</div>